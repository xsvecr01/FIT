/**
 * @file Payload.java
 * @brief Payload class
 * @author Radek Svec
 * Contact: xsvecr01@stud.fit.vutbr.cz
 */
package com.example.hexcontrol;

import java.util.FormatFlagsConversionMismatchException;

public class Payload{
    public int Strength = 0;
    public int Angle = 0;
    public int Position = 0;
    public int Height = 1;
    public int Gait = 33;
    public int RotL = 0;
    public int RotR = 0;

    @Override
    public String toString() {
        return Strength + ";" + Angle + ";" + Position + ";" + Height + ";" + Gait + ";" + RotL + ";" + RotR + ";";
    }

    public boolean equals(Payload p) {
        return p.Strength == Strength &&
                p.Angle == Angle &&
                p.Position == Position &&
                p.Height == Height &&
                p.Gait == Gait &&
                p.RotL == RotL &&
                p.RotR == RotR;
    }

    public void copy(Payload p) {
        Strength = p.Strength;
        Angle = p.Angle;
        Position = p.Position;
        Height = p.Height;
        Gait = p.Gait;
        RotL = p.RotL;
        RotR = p.RotR;
    }
}
