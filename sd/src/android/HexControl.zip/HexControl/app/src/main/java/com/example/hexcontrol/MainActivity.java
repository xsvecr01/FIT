/**
 * @file MainActiviy.java
 * @brief Main android activity
 * @author Radek Svec
 * Contact: xsvecr01@stud.fit.vutbr.cz
 */

package com.example.hexcontrol;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Timer;
import java.util.TimerTask;

import io.github.controlwear.virtual.joystick.android.JoystickView;

public class MainActivity extends AppCompatActivity {

    Button position, high1, high2, high3, gait33, gait42, gait51;
    TextView text_state;
    JoystickView joystick;
    ImageView rot_left, rot_right;

    Payload payload = new Payload();
    Payload prevP = new Payload();

    boolean startTouch = false;

    Thread Thread1 = null;
    String SERVER_IP = "192.168.4.1";
    int SERVER_PORT = 51136;

    private Socket s;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        joystick = findViewById(R.id.joystick);
        position = findViewById(R.id.position);
        high1 = findViewById(R.id.high1);
        high2 = findViewById(R.id.high2);
        high3 = findViewById(R.id.high3);
        gait33 = findViewById(R.id.gait33);
        gait42 = findViewById(R.id.gait42);
        gait51 = findViewById(R.id.gait51);

        text_state = findViewById(R.id.text_state);
        rot_left = findViewById(R.id.rot_left);
        rot_right = findViewById(R.id.rot_right);

        position.setOnClickListener(v -> {
            if(position.getText().equals("standing")) {
                position.setText("folded");
                payload.Position = 0;
            } else {
                position.setText("standing");
                payload.Position = 1;
            }
            sendValues();
        });

        high1.setOnClickListener(v -> {
            if(payload.Strength != 0)
                return;
            payload.Height = 0;
            high1.setBackgroundColor(Color.parseColor("#ffffffff"));
            high2.setBackgroundColor(Color.parseColor("#ff33b5e5"));
            high3.setBackgroundColor(Color.parseColor("#ff33b5e5"));
            sendValues();
        });

        high2.setOnClickListener(v -> {
            if(payload.Strength != 0)
                return;
            payload.Height = 1;
            high2.setBackgroundColor(Color.parseColor("#ffffffff"));
            high1.setBackgroundColor(Color.parseColor("#ff33b5e5"));
            high3.setBackgroundColor(Color.parseColor("#ff33b5e5"));
            sendValues();
        });

        high3.setOnClickListener(v -> {
            if(payload.Strength != 0)
                return;
            payload.Height = 2;
            high3.setBackgroundColor(Color.parseColor("#ffffffff"));
            high1.setBackgroundColor(Color.parseColor("#ff33b5e5"));
            high2.setBackgroundColor(Color.parseColor("#ff33b5e5"));
            sendValues();
        });

        gait33.setOnClickListener(v -> {
            if(payload.Strength != 0)
                return;
            payload.Gait = 33;
            gait33.setBackgroundColor(Color.parseColor("#ffffffff"));
            gait42.setBackgroundColor(Color.parseColor("#ff33b5e5"));
            gait51.setBackgroundColor(Color.parseColor("#ff33b5e5"));
            sendValues();
        });

        gait42.setOnClickListener(v -> {
            if(payload.Strength != 0)
                return;
            payload.Gait = 42;
            gait42.setBackgroundColor(Color.parseColor("#ffffffff"));
            gait33.setBackgroundColor(Color.parseColor("#ff33b5e5"));
            gait51.setBackgroundColor(Color.parseColor("#ff33b5e5"));
            sendValues();
        });

        gait51.setOnClickListener(v -> {
            if(payload.Strength != 0)
                return;
            payload.Gait = 51;
            gait51.setBackgroundColor(Color.parseColor("#ffffffff"));
            gait33.setBackgroundColor(Color.parseColor("#ff33b5e5"));
            gait42.setBackgroundColor(Color.parseColor("#ff33b5e5"));
            sendValues();
        });

        rot_left.setOnTouchListener((v, event) -> {
            if(event.getAction() == MotionEvent.ACTION_DOWN) {
                if(payload.RotR == 0) {
                    payload.RotL = 1;
                    sendValues();
                    return true;
                }
            }
            else if (event.getAction() == MotionEvent.ACTION_UP) {
                payload.RotL = 0;
                sendValues();
                return true;
            }
            return false;
        });

        rot_right.setOnTouchListener((v, event) -> {
            if(event.getAction() == MotionEvent.ACTION_DOWN) {
                if(payload.RotL == 0) {
                    payload.RotR = 1;
                    sendValues();
                    return true;
                }
            }
            else if (event.getAction() == MotionEvent.ACTION_UP) {
                payload.RotR = 0;
                sendValues();
                return true;
            }
            return false;
        });

        joystick.setOnTouchListener((v, event) -> {
            if(event.getAction() == MotionEvent.ACTION_DOWN) {
                payload.Angle = 0;
                payload.Strength = 0;
                startTouch = true;
            }
            return false;
        });

        joystick.setOnMoveListener((angle, strength) -> {
            payload.Angle = angle;
            if(startTouch && strength <= 50) {
                return;
            }
            else if(startTouch && strength > 50) {
                startTouch = false;
            }
            else if(strength > 0) {
                payload.Strength = 1;
            }
            else {
                payload.Strength = 0;
            }
            sendValues();
        });
    }

    private PrintWriter output;
    private BufferedReader input;

    @Override
    protected void onStart() {
        super.onStart();

        final long period = 900;
        new Timer().schedule(new TimerTask() {
            @Override
            public void run() {

                if(Thread1 == null) {
                    Thread1 = new Thread(new Thread1());
                    Thread1.start();
                }
                else {
                    String message = "i";
                    new Thread(new Thread3(message)).start();
                }
            }
        }, 0, period);
    }

    private void sendValues() {
        if(payload.equals(prevP)) {
            return;
        }

        String message = payload.toString();
        Log.d("payload", message);
        if (!message.isEmpty()) {
            new Thread(new Thread3(message)).start();
        }
        prevP.copy(payload);
    }

    class Thread1 implements Runnable {
        public void run() {
            Socket socket = null;
            try {
                socket = new Socket(SERVER_IP, SERVER_PORT);
                output = new PrintWriter(socket.getOutputStream());
                input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        text_state.setText("Connected");
                        text_state.setTextColor(Color.parseColor("#99CC00"));
                    }
                });
                new Thread(new Thread2()).start();
            } catch (IOException e) {
                Thread1 = null;
                text_state.setText("Disconnected");
                text_state.setTextColor(Color.parseColor("#FF4444"));
                e.printStackTrace();
            }
        }
    }

    class Thread2 implements Runnable {
        @Override
        public void run() {
            while (true) {
                try {
                    final String message = input.readLine();
                    if (message != null) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                //tvMessages.append("server: " + message + "\n");
                            }
                        });
                    } else {
                        Thread1 = new Thread(new Thread1());
                        Thread1.start();
                        return;
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    class Thread3 implements Runnable {
        private String message;
        Thread3(String message) {
            this.message = message;
        }
        @Override
        public void run() {
            if(output != null) {
                output.write(message);
                output.flush();
            }
        }
    }
}